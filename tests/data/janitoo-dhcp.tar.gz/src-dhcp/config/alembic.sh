#!/bin/bash
alembic -c janitoo_dhcpd.conf -n database $*
