"""Add heartbeat to dhcp leases

Revision ID: 4b171cea0760
Revises: 1e786e2e043c
Create Date: 2015-09-06 16:02:10.878621

"""

# revision identifiers, used by Alembic.
revision = '4b171cea0760'
down_revision = '1e786e2e043c'
branch_labels = None
depends_on = None

from alembic import op
import sqlalchemy as sa

def upgrade():
    op.add_column('dhcpd_lease', sa.Column('hearbeat', sa.Integer))

def downgrade():
    op.drop_column('dhcpd_lease', 'hearbeat')
