# -*- coding: utf-8 -*-
"""The dhcp controller client

At start, the controller must get new or lock leases for himself and its nodes.
It must also send heartbeat to the dhpc server.
At the end, it must release all leases

How we should use it :

- openzwave : nodes appears on notification, can be added to network by external commands.
 - when node has its essential informations, we check

- roomba : need an ip address, a user and a password.
 - at first start, the roomba server has no hadd for its controller. So it request a new one.
 - After, the server will lock all leases for himself and its nodes usinf (add_ctrl,-1). He will receive lease for itsel and all its nodes at a time.

 To add a new node :
  - the controller has subscribed to /machines/config/add_ctrl:#
  - the core check that command_class add_node is implemented by the controller and retrieve all types of nodes that can be added.
  - the core get config parameters for this type of node from the crontoller (use values config of zwave)
  - the core get parameters from user
  - the core create the lease with user values on the dhcpd server.
  - the dhcp server create the lease for hadd and publish message to /machines/config/hadd
  - the controller receive the config on /machines/config/add_ctrl:add_node and start the node

 To update a node :
  - the controller has subscribed to /machines/config/add_ctrl:#
  - the core resolv_hadd from the dhcp server
  - the core get config parameters for this node from the crontoller (use values config of zwave)
  - the core get new parameters from user
  - the core repair_lease with user values on the dhcpd server.
  - the dhcp server update the lease for hadd and publish message to /machines/config/hadd
  - the controller receive the config on /machines/config/add_ctrl:add_node and update the node/controller

Boot sequence:
  if the controller has no previous hadd, get a new one and release it

  if one :
   - subscribe to /machines/config/add_ctrl:#
   - on message : update name, locaton, if needed we can restart the node ...
   - lock the hadd : add_ctrl:-1 : this


zwave api_demo :
Memory use : 14.50390625 Mo
------------------------------------------------------------
Use openzwave library : 1.3.167
Use python library : 0.3.0-beta1
Use ZWave library : Static Controller version Z-Wave 2.78
Network home id : 0x014d0ef5
Controller node id : 1
Controller node version : 3
Nodes in network : 4
------------------------------------------------------------
Waiting for network ready :
------------------------------------------------------------
 done in 3 seconds
Memory use : 14.50390625 Mo
------------------------------------------------------------
Controller capabilities : set(['primaryController', 'staticUpdateController'])
Controller node capabilities : set(['primaryController', 'beaming', 'listening', 'staticUpdateController'])
Nodes in network : 4
Driver statistics : {'retries': 0, 'readCnt': 182, 'readAborts': 0, 'routedbusy': 0, 'ACKCnt': 73, 'OOFCnt': 0, 'noack': 0, 'broadcastWriteCnt': 9, 'callbacks': 0, 'writeCnt': 73, 'badChecksum': 0, 'nondelivery': 0, 'CANCnt': 0, 'NAKCnt': 0, 'netbusy': 0, 'SOFCnt': 182, 'broadcastReadCnt': 0, 'badroutes': 0, 'ACKWaiting': 0, 'dropped': 0}
------------------------------------------------------------

------------------------------------------------------------
11 - Name :
11 - Manufacturer name / id :  /
11 - Product name / id / type :  /  /
11 - Version : 2
11 - Command classes : set(['COMMAND_CLASS_PROTECTION', 'COMMAND_CLASS_SWITCH_MULTILEVEL', 'COMMAND_CLASS_NO_OPERATION', 'COMMAND_CLASS_BASIC', 'COMMAND_CLASS_SWITCH_ALL'])
11 - Capabilities : set(['routing', 'listening'])
11 - Neigbors : set([1, 3, 4])
11 - Can sleep : False
11 - Groups : {}
   ---------
11 - Values for command class : COMMAND_CLASS_NO_OPERATION : {}
   ---------
11 - Values for command class : COMMAND_CLASS_BASIC : {}
   ---------
11 - Values for command class : COMMAND_CLASS_PROTECTION : {72057594236977156L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'System', 'data': 'No Operation Possible', 'min': 0, 'writeonly': False, 'label': 'Protection', 'readonly': False, 'data_str': 'No Operation Possible', 'type': 'List'}}
   ---------
11 - Values for command class : COMMAND_CLASS_SWITCH_MULTILEVEL : {72057594227294248L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'User', 'data': False, 'min': 0, 'writeonly': True, 'label': 'Dim', 'readonly': False, 'data_str': False, 'type': 'Button'}, 72057594227294209L: {'help': '', 'max': 255, 'ispolled': False, 'units': '', 'genre': 'User', 'data': 74, 'min': 0, 'writeonly': False, 'label': 'Level', 'readonly': False, 'data_str': 74, 'type': 'Byte'}, 72057594235682881L: {'help': '', 'max': 255, 'ispolled': False, 'units': '', 'genre': 'System', 'data': 0, 'min': 0, 'writeonly': False, 'label': 'Start Level', 'readonly': False, 'data_str': 0, 'type': 'Byte'}, 72057594227294232L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'User', 'data': False, 'min': 0, 'writeonly': True, 'label': 'Bright', 'readonly': False, 'data_str': False, 'type': 'Button'}, 72057594235682864L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'System', 'data': True, 'min': 0, 'writeonly': False, 'label': 'Ignore Start Level', 'readonly': False, 'data_str': True, 'type': 'Bool'}}
   ---------
11 - Values for command class : COMMAND_CLASS_SWITCH_ALL : {72057594235699204L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'System', 'data': 'Disabled', 'min': 0, 'writeonly': False, 'label': 'Switch All', 'readonly': False, 'data_str': 'Disabled', 'type': 'List'}}
------------------------------------------------------------

------------------------------------------------------------
1 - Name :
1 - Manufacturer name / id : Aeon Labs / 0086
1 - Product name / id / type : Z-Stick S2 / 0001 / 0002
1 - Version : 3
1 - Command classes : set(['COMMAND_CLASS_NO_OPERATION', 'COMMAND_CLASS_BASIC'])
1 - Capabilities : set(['primaryController', 'beaming', 'listening', 'staticUpdateController'])
1 - Neigbors : set([11, 3, 4])
1 - Can sleep : False
1 - Groups : {}
   ---------
1 - Values for command class : COMMAND_CLASS_NO_OPERATION : {}
   ---------
1 - Values for command class : COMMAND_CLASS_BASIC : {72057594055229441L: {'help': '', 'max': 255, 'ispolled': False, 'units': '', 'genre': 'Basic', 'data': 0, 'min': 0, 'writeonly': False, 'label': 'Basic', 'readonly': False, 'data_str': 0, 'type': 'Byte'}}
------------------------------------------------------------

------------------------------------------------------------
3 - Name :
3 - Manufacturer name / id : Everspring / 0060
3 - Product name / id / type : AN158 Plug-in Meter Appliance Module / 0002 / 0004
3 - Version : 3
3 - Command classes : set(['COMMAND_CLASS_SWITCH_ALL', 'COMMAND_CLASS_SWITCH_BINARY', 'COMMAND_CLASS_BASIC', 'COMMAND_CLASS_MANUFACTURER_SPECIFIC', 'COMMAND_CLASS_CONFIGURATION', 'COMMAND_CLASS_NO_OPERATION', 'COMMAND_CLASS_VERSION', 'COMMAND_CLASS_ASSOCIATION', 'COMMAND_CLASS_METER'])
3 - Capabilities : set(['beaming', 'routing', 'listening'])
3 - Neigbors : set([1, 11, 4])
3 - Can sleep : False
3 - Groups : {1: {'associations': set([1]), 'label': 'Reports'}, 2: {'associations': set([1]), 'label': 'Basic'}}
   ---------
3 - Values for command class : COMMAND_CLASS_NO_OPERATION : {}
   ---------
3 - Values for command class : COMMAND_CLASS_BASIC : {}
   ---------
3 - Values for command class : COMMAND_CLASS_SWITCH_BINARY : {72057594093060096L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'User', 'data': False, 'min': 0, 'writeonly': False, 'label': 'Switch', 'readonly': False, 'data_str': False, 'type': 'Bool'}}
   ---------
3 - Values for command class : COMMAND_CLASS_VERSION : {72057594103037959L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'System', 'data': '6', 'min': 0, 'writeonly': False, 'label': 'Library Version', 'readonly': True, 'data_str': '6', 'type': 'String'}, 72057594103037975L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'System', 'data': '2.64', 'min': 0, 'writeonly': False, 'label': 'Protocol Version', 'readonly': True, 'data_str': '2.64', 'type': 'String'}, 72057594103037991L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'System', 'data': '1.01', 'min': 0, 'writeonly': False, 'label': 'Application Version', 'readonly': True, 'data_str': '1.01', 'type': 'String'}}
   ---------
3 - Values for command class : COMMAND_CLASS_SWITCH_ALL : {72057594101481476L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'System', 'data': 'Disabled', 'min': 0, 'writeonly': False, 'label': 'Switch All', 'readonly': False, 'data_str': 'Disabled', 'type': 'List'}}
   ---------
3 - Values for command class : COMMAND_CLASS_MANUFACTURER_SPECIFIC : {}
   ---------
3 - Values for command class : COMMAND_CLASS_CONFIGURATION : {72057594098483233L: {'help': 'Enable or Disable Send Basic Command to Group 2 when the local button press changes the switching state.', 'max': 1, 'ispolled': False, 'units': '', 'genre': 'Config', 'data': 0, 'min': 0, 'writeonly': False, 'label': 'Send Out Basic Command', 'readonly': False, 'data_str': 0, 'type': 'Byte'}, 72057594098483254L: {'help': 'The device will report its meter value within the interval set. Set to 0 will disable the autoreporting function.', 'max': 3240, 'ispolled': False, 'units': '10s', 'genre': 'Config', 'data': 3, 'min': 0, 'writeonly': False, 'label': 'Meter Report Period', 'readonly': False, 'data_str': 3, 'type': 'Short'}, 72057594098483222L: {'help': 'This is the time the switching status needs to remain unchanged after a change to cause the device to send out a status message. 0 is Disabled.', 'max': 120, 'ispolled': False, 'units': '100ms', 'genre': 'Config', 'data': 10, 'min': 0, 'writeonly': False, 'label': 'True Period', 'readonly': False, 'data_str': 10, 'type': 'Short'}}
   ---------
3 - Values for command class : COMMAND_CLASS_METER : {72057594093273600L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'User', 'data': False, 'min': 0, 'writeonly': False, 'label': 'Exporting', 'readonly': True, 'data_str': False, 'type': 'Bool'}, 72057594101662232L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'System', 'data': False, 'min': 0, 'writeonly': True, 'label': 'Reset', 'readonly': False, 'data_str': False, 'type': 'Button'}, 72057594093273090L: {'help': '', 'max': 0, 'ispolled': False, 'units': 'kWh', 'genre': 'User', 'data': 0.0, 'min': 0, 'writeonly': False, 'label': 'Energy', 'readonly': True, 'data_str': 0.0, 'type': 'Decimal'}, 72057594093273218L: {'help': '', 'max': 0, 'ispolled': False, 'units': 'W', 'genre': 'User', 'data': 0.0, 'min': 0, 'writeonly': False, 'label': 'Power', 'readonly': True, 'data_str': 0.0, 'type': 'Decimal'}}
   ---------
3 - Values for command class : COMMAND_CLASS_ASSOCIATION : {}
------------------------------------------------------------

------------------------------------------------------------
4 - Name :
4 - Manufacturer name / id : GreenWave / 0099
4 - Product name / id / type : PowerNode 6 port / 0004 / 0003
4 - Version : 4
4 - Command classes : set(['COMMAND_CLASS_MULTI_CHANNEL_V2', 'COMMAND_CLASS_SWITCH_BINARY', 'COMMAND_CLASS_BASIC', 'COMMAND_CLASS_MANUFACTURER_SPECIFIC', 'COMMAND_CLASS_SWITCH_ALL', 'COMMAND_CLASS_CONFIGURATION', 'COMMAND_CLASS_PROTECTION', 'COMMAND_CLASS_NO_OPERATION', 'COMMAND_CLASS_VERSION', 'COMMAND_CLASS_ASSOCIATION', 'COMMAND_CLASS_METER'])
4 - Capabilities : set(['beaming', 'routing', 'listening'])
4 - Neigbors : set([11, 1, 3])
4 - Can sleep : False
4 - Groups : {1: {'associations': set([1]), 'label': 'Group 1'}, 2: {'associations': set([]), 'label': 'Group 2'}, 3: {'associations': set([]), 'label': 'Group 3'}, 4: {'associations': set([]), 'label': 'Group 4'}}
   ---------
4 - Values for command class : COMMAND_CLASS_NO_OPERATION : {}
   ---------
4 - Values for command class : COMMAND_CLASS_BASIC : {}
   ---------
4 - Values for command class : COMMAND_CLASS_SWITCH_BINARY : {72057594109837312L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'User', 'data': False, 'min': 0, 'writeonly': False, 'label': 'Switch', 'readonly': False, 'data_str': False, 'type': 'Bool'}, 144115188147765248L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'User', 'data': False, 'min': 0, 'writeonly': False, 'label': 'Switch', 'readonly': False, 'data_str': False, 'type': 'Bool'}, 216172782185693184L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'User', 'data': False, 'min': 0, 'writeonly': False, 'label': 'Switch', 'readonly': False, 'data_str': False, 'type': 'Bool'}, 432345564299476992L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'User', 'data': False, 'min': 0, 'writeonly': False, 'label': 'Switch', 'readonly': False, 'data_str': False, 'type': 'Bool'}, 360287970261549056L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'User', 'data': False, 'min': 0, 'writeonly': False, 'label': 'Switch', 'readonly': False, 'data_str': False, 'type': 'Bool'}, 288230376223621120L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'User', 'data': False, 'min': 0, 'writeonly': False, 'label': 'Switch', 'readonly': False, 'data_str': False, 'type': 'Bool'}}
   ---------
4 - Values for command class : COMMAND_CLASS_VERSION : {72057594119815191L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'System', 'data': '3.41', 'min': 0, 'writeonly': False, 'label': 'Protocol Version', 'readonly': True, 'data_str': '3.41', 'type': 'String'}, 72057594119815207L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'System', 'data': '4.27', 'min': 0, 'writeonly': False, 'label': 'Application Version', 'readonly': True, 'data_str': '4.27', 'type': 'String'}, 72057594119815175L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'System', 'data': '3', 'min': 0, 'writeonly': False, 'label': 'Library Version', 'readonly': True, 'data_str': '3', 'type': 'String'}}
   ---------
4 - Values for command class : COMMAND_CLASS_SWITCH_ALL : {72057594118258692L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'System', 'data': 'Disabled', 'min': 0, 'writeonly': False, 'label': 'Switch All', 'readonly': False, 'data_str': 'Disabled', 'type': 'List'}}
   ---------
4 - Values for command class : COMMAND_CLASS_MULTI_CHANNEL_V2 : {}
   ---------
4 - Values for command class : COMMAND_CLASS_MANUFACTURER_SPECIFIC : {}
   ---------
4 - Values for command class : COMMAND_CLASS_CONFIGURATION : {72057594115260433L: {'help': "After how many minutes the GreenWave device should start flashing if the controller didn't communicate with this device", 'max': 255, 'ispolled': False, 'units': '', 'genre': 'Config', 'data': 2, 'min': 1, 'writeonly': False, 'label': 'No communication light', 'readonly': False, 'data_str': 2, 'type': 'Byte'}, 72057594115260452L: {'help': 'The room color (Corner wheel color) on the GreenWave device', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'Config', 'data': 'Black (empty)', 'min': 0, 'writeonly': False, 'label': 'Room color', 'readonly': True, 'data_str': 'Black (empty)', 'type': 'List'}}
   ---------
4 - Values for command class : COMMAND_CLASS_METER : {144115188147978752L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'User', 'data': False, 'min': 0, 'writeonly': False, 'label': 'Exporting', 'readonly': True, 'data_str': False, 'type': 'Bool'}, 72057594110050816L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'User', 'data': False, 'min': 0, 'writeonly': False, 'label': 'Exporting', 'readonly': True, 'data_str': False, 'type': 'Bool'}, 288230376223834114L: {'help': '', 'max': 0, 'ispolled': False, 'units': 'kWh', 'genre': 'User', 'data': 0.0, 'min': 0, 'writeonly': False, 'label': 'Energy', 'readonly': True, 'data_str': 0.0, 'type': 'Decimal'}, 432345564299690002L: {'help': '', 'max': 0, 'ispolled': False, 'units': 'kWh', 'genre': 'User', 'data': 0.0, 'min': 0, 'writeonly': False, 'label': 'Previous Reading', 'readonly': True, 'data_str': 0.0, 'type': 'Decimal'}, 360287970261762066L: {'help': '', 'max': 0, 'ispolled': False, 'units': 'kWh', 'genre': 'User', 'data': 0.0, 'min': 0, 'writeonly': False, 'label': 'Previous Reading', 'readonly': True, 'data_str': 0.0, 'type': 'Decimal'}, 432345564299690114L: {'help': '', 'max': 0, 'ispolled': False, 'units': 'W', 'genre': 'User', 'data': 0.0, 'min': 0, 'writeonly': False, 'label': 'Power', 'readonly': True, 'data_str': 0.0, 'type': 'Decimal'}, 288230376223834258L: {'help': '', 'max': 0, 'ispolled': False, 'units': 'W', 'genre': 'User', 'data': 0.0, 'min': 0, 'writeonly': False, 'label': 'Previous Reading', 'readonly': True, 'data_str': 0.0, 'type': 'Decimal'}, 432345564299690496L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'User', 'data': False, 'min': 0, 'writeonly': False, 'label': 'Exporting', 'readonly': True, 'data_str': False, 'type': 'Bool'}, 360287970270151192L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'System', 'data': False, 'min': 0, 'writeonly': True, 'label': 'Reset', 'readonly': False, 'data_str': False, 'type': 'Button'}, 72057594110050450L: {'help': '', 'max': 0, 'ispolled': False, 'units': 'W', 'genre': 'User', 'data': 0.0, 'min': 0, 'writeonly': False, 'label': 'Previous Reading', 'readonly': True, 'data_str': 0.0, 'type': 'Decimal'}, 144115188147978275L: {'help': '', 'max': 2147483647, 'ispolled': False, 'units': 'seconds', 'genre': 'User', 'data': 9, 'min': 2147483648, 'writeonly': False, 'label': 'Interval', 'readonly': True, 'data_str': 9, 'type': 'Int'}, 360287970261762178L: {'help': '', 'max': 0, 'ispolled': False, 'units': 'W', 'genre': 'User', 'data': 0.0, 'min': 0, 'writeonly': False, 'label': 'Power', 'readonly': True, 'data_str': 0.0, 'type': 'Decimal'}, 288230376223834624L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'User', 'data': False, 'min': 0, 'writeonly': False, 'label': 'Exporting', 'readonly': True, 'data_str': False, 'type': 'Bool'}, 216172782194295320L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'System', 'data': False, 'min': 0, 'writeonly': True, 'label': 'Reset', 'readonly': False, 'data_str': False, 'type': 'Button'}, 288230376223834130L: {'help': '', 'max': 0, 'ispolled': False, 'units': 'kWh', 'genre': 'User', 'data': 0.0, 'min': 0, 'writeonly': False, 'label': 'Previous Reading', 'readonly': True, 'data_str': 0.0, 'type': 'Decimal'}, 288230376223834147L: {'help': '', 'max': 2147483647, 'ispolled': False, 'units': 'seconds', 'genre': 'User', 'data': 9, 'min': 2147483648, 'writeonly': False, 'label': 'Interval', 'readonly': True, 'data_str': 9, 'type': 'Int'}, 144115188156367384L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'System', 'data': False, 'min': 0, 'writeonly': True, 'label': 'Reset', 'readonly': False, 'data_str': False, 'type': 'Button'}, 216172782185906211L: {'help': '', 'max': 2147483647, 'ispolled': False, 'units': 'seconds', 'genre': 'User', 'data': 9, 'min': 2147483648, 'writeonly': False, 'label': 'Interval', 'readonly': True, 'data_str': 9, 'type': 'Int'}, 72057594110050322L: {'help': '', 'max': 0, 'ispolled': False, 'units': 'kWh', 'genre': 'User', 'data': 0.0, 'min': 0, 'writeonly': False, 'label': 'Previous Reading', 'readonly': True, 'data_str': 0.0, 'type': 'Decimal'}, 432345564299690019L: {'help': '', 'max': 2147483647, 'ispolled': False, 'units': 'seconds', 'genre': 'User', 'data': 9, 'min': 2147483648, 'writeonly': False, 'label': 'Interval', 'readonly': True, 'data_str': 9, 'type': 'Int'}, 144115188147978403L: {'help': '', 'max': 2147483647, 'ispolled': False, 'units': 'seconds', 'genre': 'User', 'data': 9, 'min': 2147483648, 'writeonly': False, 'label': 'Interval', 'readonly': True, 'data_str': 9, 'type': 'Int'}, 144115188147978386L: {'help': '', 'max': 0, 'ispolled': False, 'units': 'W', 'genre': 'User', 'data': 0.0, 'min': 0, 'writeonly': False, 'label': 'Previous Reading', 'readonly': True, 'data_str': 0.0, 'type': 'Decimal'}, 288230376223834242L: {'help': '', 'max': 0, 'ispolled': False, 'units': 'W', 'genre': 'User', 'data': 0.0, 'min': 0, 'writeonly': False, 'label': 'Power', 'readonly': True, 'data_str': 0.0, 'type': 'Decimal'}, 360287970261762050L: {'help': '', 'max': 0, 'ispolled': False, 'units': 'kWh', 'genre': 'User', 'data': 0.0, 'min': 0, 'writeonly': False, 'label': 'Energy', 'readonly': True, 'data_str': 0.0, 'type': 'Decimal'}, 144115188147978242L: {'help': '', 'max': 0, 'ispolled': False, 'units': 'kWh', 'genre': 'User', 'data': 0.0, 'min': 0, 'writeonly': False, 'label': 'Energy', 'readonly': True, 'data_str': 0.0, 'type': 'Decimal'}, 432345564308079128L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'System', 'data': False, 'min': 0, 'writeonly': True, 'label': 'Reset', 'readonly': False, 'data_str': False, 'type': 'Button'}, 360287970261762211L: {'help': '', 'max': 2147483647, 'ispolled': False, 'units': 'seconds', 'genre': 'User', 'data': 9, 'min': 2147483648, 'writeonly': False, 'label': 'Interval', 'readonly': True, 'data_str': 9, 'type': 'Int'}, 72057594110050306L: {'help': '', 'max': 0, 'ispolled': False, 'units': 'kWh', 'genre': 'User', 'data': 0.0, 'min': 0, 'writeonly': False, 'label': 'Energy', 'readonly': True, 'data_str': 0.0, 'type': 'Decimal'}, 216172782185906688L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'User', 'data': False, 'min': 0, 'writeonly': False, 'label': 'Exporting', 'readonly': True, 'data_str': False, 'type': 'Bool'}, 216172782185906178L: {'help': '', 'max': 0, 'ispolled': False, 'units': 'kWh', 'genre': 'User', 'data': 0.0, 'min': 0, 'writeonly': False, 'label': 'Energy', 'readonly': True, 'data_str': 0.0, 'type': 'Decimal'}, 360287970261762083L: {'help': '', 'max': 2147483647, 'ispolled': False, 'units': 'seconds', 'genre': 'User', 'data': 9, 'min': 2147483648, 'writeonly': False, 'label': 'Interval', 'readonly': True, 'data_str': 9, 'type': 'Int'}, 216172782185906306L: {'help': '', 'max': 0, 'ispolled': False, 'units': 'W', 'genre': 'User', 'data': 0.0, 'min': 0, 'writeonly': False, 'label': 'Power', 'readonly': True, 'data_str': 0.0, 'type': 'Decimal'}, 216172782185906322L: {'help': '', 'max': 0, 'ispolled': False, 'units': 'W', 'genre': 'User', 'data': 0.0, 'min': 0, 'writeonly': False, 'label': 'Previous Reading', 'readonly': True, 'data_str': 0.0, 'type': 'Decimal'}, 216172782185906194L: {'help': '', 'max': 0, 'ispolled': False, 'units': 'kWh', 'genre': 'User', 'data': 0.0, 'min': 0, 'writeonly': False, 'label': 'Previous Reading', 'readonly': True, 'data_str': 0.0, 'type': 'Decimal'}, 432345564299690147L: {'help': '', 'max': 2147483647, 'ispolled': False, 'units': 'seconds', 'genre': 'User', 'data': 9, 'min': 2147483648, 'writeonly': False, 'label': 'Interval', 'readonly': True, 'data_str': 9, 'type': 'Int'}, 72057594118439448L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'System', 'data': False, 'min': 0, 'writeonly': True, 'label': 'Reset', 'readonly': False, 'data_str': False, 'type': 'Button'}, 72057594110050467L: {'help': '', 'max': 2147483647, 'ispolled': False, 'units': 'seconds', 'genre': 'User', 'data': 9, 'min': 2147483648, 'writeonly': False, 'label': 'Interval', 'readonly': True, 'data_str': 9, 'type': 'Int'}, 288230376223834275L: {'help': '', 'max': 2147483647, 'ispolled': False, 'units': 'seconds', 'genre': 'User', 'data': 9, 'min': 2147483648, 'writeonly': False, 'label': 'Interval', 'readonly': True, 'data_str': 9, 'type': 'Int'}, 216172782185906339L: {'help': '', 'max': 2147483647, 'ispolled': False, 'units': 'seconds', 'genre': 'User', 'data': 9, 'min': 2147483648, 'writeonly': False, 'label': 'Interval', 'readonly': True, 'data_str': 9, 'type': 'Int'}, 432345564299690130L: {'help': '', 'max': 0, 'ispolled': False, 'units': 'W', 'genre': 'User', 'data': 0.0, 'min': 0, 'writeonly': False, 'label': 'Previous Reading', 'readonly': True, 'data_str': 0.0, 'type': 'Decimal'}, 360287970261762560L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'User', 'data': False, 'min': 0, 'writeonly': False, 'label': 'Exporting', 'readonly': True, 'data_str': False, 'type': 'Bool'}, 288230376232223256L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'System', 'data': False, 'min': 0, 'writeonly': True, 'label': 'Reset', 'readonly': False, 'data_str': False, 'type': 'Button'}, 144115188147978370L: {'help': '', 'max': 0, 'ispolled': False, 'units': 'W', 'genre': 'User', 'data': 0.0, 'min': 0, 'writeonly': False, 'label': 'Power', 'readonly': True, 'data_str': 0.0, 'type': 'Decimal'}, 432345564299689986L: {'help': '', 'max': 0, 'ispolled': False, 'units': 'kWh', 'genre': 'User', 'data': 0.0, 'min': 0, 'writeonly': False, 'label': 'Energy', 'readonly': True, 'data_str': 0.0, 'type': 'Decimal'}, 144115188147978258L: {'help': '', 'max': 0, 'ispolled': False, 'units': 'kWh', 'genre': 'User', 'data': 0.0, 'min': 0, 'writeonly': False, 'label': 'Previous Reading', 'readonly': True, 'data_str': 0.0, 'type': 'Decimal'}, 360287970261762194L: {'help': '', 'max': 0, 'ispolled': False, 'units': 'W', 'genre': 'User', 'data': 0.0, 'min': 0, 'writeonly': False, 'label': 'Previous Reading', 'readonly': True, 'data_str': 0.0, 'type': 'Decimal'}, 72057594110050339L: {'help': '', 'max': 2147483647, 'ispolled': False, 'units': 'seconds', 'genre': 'User', 'data': 9, 'min': 2147483648, 'writeonly': False, 'label': 'Interval', 'readonly': True, 'data_str': 9, 'type': 'Int'}, 72057594110050434L: {'help': '', 'max': 0, 'ispolled': False, 'units': 'W', 'genre': 'User', 'data': 0.0, 'min': 0, 'writeonly': False, 'label': 'Power', 'readonly': True, 'data_str': 0.0, 'type': 'Decimal'}}
   ---------
4 - Values for command class : COMMAND_CLASS_PROTECTION : {432345564309176324L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'System', 'data': 'Unprotected', 'min': 0, 'writeonly': False, 'label': 'Protection', 'readonly': False, 'data_str': 'Unprotected', 'type': 'List'}, 216172782195392516L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'System', 'data': 'Unprotected', 'min': 0, 'writeonly': False, 'label': 'Protection', 'readonly': False, 'data_str': 'Unprotected', 'type': 'List'}, 72057594119536644L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'System', 'data': 'Unprotected', 'min': 0, 'writeonly': False, 'label': 'Protection', 'readonly': False, 'data_str': 'Unprotected', 'type': 'List'}, 360287970271248388L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'System', 'data': 'Unprotected', 'min': 0, 'writeonly': False, 'label': 'Protection', 'readonly': False, 'data_str': 'Unprotected', 'type': 'List'}, 288230376233320452L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'System', 'data': 'Unprotected', 'min': 0, 'writeonly': False, 'label': 'Protection', 'readonly': False, 'data_str': 'Unprotected', 'type': 'List'}, 144115188157464580L: {'help': '', 'max': 0, 'ispolled': False, 'units': '', 'genre': 'System', 'data': 'Unprotected', 'min': 0, 'writeonly': False, 'label': 'Protection', 'readonly': False, 'data_str': 'Unprotected', 'type': 'List'}}
   ---------
4 - Values for command class : COMMAND_CLASS_ASSOCIATION : {}
------------------------------------------------------------

------------------------------------------------------------
Driver statistics : {'retries': 0, 'readCnt': 182, 'readAborts': 0, 'routedbusy': 0, 'ACKCnt': 73, 'OOFCnt': 0, 'noack': 0, 'broadcastWriteCnt': 9, 'callbacks': 0, 'writeCnt': 73, 'badChecksum': 0, 'nondelivery': 0, 'CANCnt': 0, 'NAKCnt': 0, 'netbusy': 0, 'SOFCnt': 182, 'broadcastReadCnt': 0, 'badroutes': 0, 'ACKWaiting': 0, 'dropped': 0}
------------------------------------------------------------

------------------------------------------------------------
Try to autodetect nodes on the network
------------------------------------------------------------
Nodes in network : 4
------------------------------------------------------------
Retrieve switches on the network
------------------------------------------------------------
node/name/index/instance : 3//0/1
  label/help : Switch/
  id on the network : 014d0ef5.3.25.1.0
  state: False
node/name/index/instance : 4//0/1
  label/help : Switch/
  id on the network : 014d0ef5.4.25.1.0
  state: False
node/name/index/instance : 4//0/2
  label/help : Switch/
  id on the network : 014d0ef5.4.25.2.0
  state: False
node/name/index/instance : 4//0/4
  label/help : Switch/
  id on the network : 014d0ef5.4.25.4.0
  state: False
node/name/index/instance : 4//0/5
  label/help : Switch/
  id on the network : 014d0ef5.4.25.5.0
  state: False
node/name/index/instance : 4//0/6
  label/help : Switch/
  id on the network : 014d0ef5.4.25.6.0
  state: False
node/name/index/instance : 4//0/3
  label/help : Switch/
  id on the network : 014d0ef5.4.25.3.0
  state: False
------------------------------------------------------------
Retrieve dimmers on the network
------------------------------------------------------------
node/name/index/instance : 11//0/1
  label/help : Level/
  id on the network : 014d0ef5.11.26.1.0
  level: 74
------------------------------------------------------------
Retrieve sensors on the network
------------------------------------------------------------
node/name/index/instance : 3//32/1
  label/help : Exporting/
  id on the network : 014d0ef5.3.32.1.32
  value: False
node/name/index/instance : 3//0/1
  label/help : Energy/
  id on the network : 014d0ef5.3.32.1.0
  value: 0.0 kWh
node/name/index/instance : 3//8/1
  label/help : Power/
  id on the network : 014d0ef5.3.32.1.8
  value: 0.0 W
node/name/index/instance : 4//32/2
  label/help : Exporting/
  id on the network : 014d0ef5.4.32.2.32
  value: False
node/name/index/instance : 4//32/1
  label/help : Exporting/
  id on the network : 014d0ef5.4.32.1.32
  value: False
node/name/index/instance : 4//0/4
  label/help : Energy/
  id on the network : 014d0ef5.4.32.4.0
  value: 0.0 kWh
node/name/index/instance : 4//1/6
  label/help : Previous Reading/
  id on the network : 014d0ef5.4.32.6.1
  value: 0.0 kWh
node/name/index/instance : 4//8/6
  label/help : Power/
  id on the network : 014d0ef5.4.32.6.8
  value: 0.0 W
node/name/index/instance : 4//9/4
  label/help : Previous Reading/
  id on the network : 014d0ef5.4.32.4.9
  value: 0.0 W
node/name/index/instance : 4//32/4
  label/help : Exporting/
  id on the network : 014d0ef5.4.32.4.32
  value: False
node/name/index/instance : 4//1/1
  label/help : Previous Reading/
  id on the network : 014d0ef5.4.32.1.1
  value: 0.0 kWh
node/name/index/instance : 4//9/1
  label/help : Previous Reading/
  id on the network : 014d0ef5.4.32.1.9
  value: 0.0 W
node/name/index/instance : 4//2/1
  label/help : Interval/
  id on the network : 014d0ef5.4.32.1.2
  value: 9 seconds
node/name/index/instance : 4//8/4
  label/help : Power/
  id on the network : 014d0ef5.4.32.4.8
  value: 0.0 W
node/name/index/instance : 4//32/6
  label/help : Exporting/
  id on the network : 014d0ef5.4.32.6.32
  value: False
node/name/index/instance : 4//1/5
  label/help : Previous Reading/
  id on the network : 014d0ef5.4.32.5.1
  value: 0.0 kWh
node/name/index/instance : 4//2/4
  label/help : Interval/
  id on the network : 014d0ef5.4.32.4.2
  value: 9 seconds
node/name/index/instance : 4//10/5
  label/help : Interval/
  id on the network : 014d0ef5.4.32.5.10
  value: 9 seconds
node/name/index/instance : 4//2/2
  label/help : Interval/
  id on the network : 014d0ef5.4.32.2.2
  value: 9 seconds
node/name/index/instance : 4//1/2
  label/help : Previous Reading/
  id on the network : 014d0ef5.4.32.2.1
  value: 0.0 kWh
node/name/index/instance : 4//2/6
  label/help : Interval/
  id on the network : 014d0ef5.4.32.6.2
  value: 9 seconds
node/name/index/instance : 4//10/6
  label/help : Interval/
  id on the network : 014d0ef5.4.32.6.10
  value: 9 seconds
node/name/index/instance : 4//9/2
  label/help : Previous Reading/
  id on the network : 014d0ef5.4.32.2.9
  value: 0.0 W
node/name/index/instance : 4//8/2
  label/help : Power/
  id on the network : 014d0ef5.4.32.2.8
  value: 0.0 W
node/name/index/instance : 4//0/5
  label/help : Energy/
  id on the network : 014d0ef5.4.32.5.0
  value: 0.0 kWh
node/name/index/instance : 4//0/6
  label/help : Energy/
  id on the network : 014d0ef5.4.32.6.0
  value: 0.0 kWh
node/name/index/instance : 4//10/1
  label/help : Interval/
  id on the network : 014d0ef5.4.32.1.10
  value: 9 seconds
node/name/index/instance : 4//0/1
  label/help : Energy/
  id on the network : 014d0ef5.4.32.1.0
  value: 0.0 kWh
node/name/index/instance : 4//32/3
  label/help : Exporting/
  id on the network : 014d0ef5.4.32.3.32
  value: False
node/name/index/instance : 4//0/3
  label/help : Energy/
  id on the network : 014d0ef5.4.32.3.0
  value: 0.0 kWh
node/name/index/instance : 4//8/1
  label/help : Power/
  id on the network : 014d0ef5.4.32.1.8
  value: 0.0 W
node/name/index/instance : 4//9/3
  label/help : Previous Reading/
  id on the network : 014d0ef5.4.32.3.9
  value: 0.0 W
node/name/index/instance : 4//1/3
  label/help : Previous Reading/
  id on the network : 014d0ef5.4.32.3.1
  value: 0.0 kWh
node/name/index/instance : 4//2/3
  label/help : Interval/
  id on the network : 014d0ef5.4.32.3.2
  value: 9 seconds
node/name/index/instance : 4//10/3
  label/help : Interval/
  id on the network : 014d0ef5.4.32.3.10
  value: 9 seconds
node/name/index/instance : 4//10/2
  label/help : Interval/
  id on the network : 014d0ef5.4.32.2.10
  value: 9 seconds
node/name/index/instance : 4//10/4
  label/help : Interval/
  id on the network : 014d0ef5.4.32.4.10
  value: 9 seconds
node/name/index/instance : 4//9/6
  label/help : Previous Reading/
  id on the network : 014d0ef5.4.32.6.9
  value: 0.0 W
node/name/index/instance : 4//32/5
  label/help : Exporting/
  id on the network : 014d0ef5.4.32.5.32
  value: False
node/name/index/instance : 4//8/3
  label/help : Power/
  id on the network : 014d0ef5.4.32.3.8
  value: 0.0 W
node/name/index/instance : 4//0/2
  label/help : Energy/
  id on the network : 014d0ef5.4.32.2.0
  value: 0.0 kWh
node/name/index/instance : 4//1/4
  label/help : Previous Reading/
  id on the network : 014d0ef5.4.32.4.1
  value: 0.0 kWh
node/name/index/instance : 4//9/5
  label/help : Previous Reading/
  id on the network : 014d0ef5.4.32.5.9
  value: 0.0 W
node/name/index/instance : 4//2/5
  label/help : Interval/
  id on the network : 014d0ef5.4.32.5.2
  value: 9 seconds
node/name/index/instance : 4//8/5
  label/help : Power/
  id on the network : 014d0ef5.4.32.5.8
  value: 0.0 W
------------------------------------------------------------
Retrieve switches all compatibles devices on the network
------------------------------------------------------------
node/name/index/instance : 11//0/1
  label/help : Switch All/
  id on the network : 014d0ef5.11.27.1.0
  value / items: Disabled / set(['Disabled', 'On and Off Enabled', 'On Enabled', 'Off Enabled'])
  state: True
node/name/index/instance : 3//0/1
  label/help : Switch All/
  id on the network : 014d0ef5.3.27.1.0
  value / items: Disabled / set(['Disabled', 'On and Off Enabled', 'On Enabled', 'Off Enabled'])
  state: False
node/name/index/instance : 4//0/1
  label/help : Switch All/
  id on the network : 014d0ef5.4.27.1.0
  value / items: Disabled / set(['Disabled', 'On and Off Enabled', 'On Enabled', 'Off Enabled'])
  state: False
------------------------------------------------------------
Retrieve protection compatibles devices on the network
------------------------------------------------------------
node/name/index/instance : 11//0/1
  label/help : Protection/
  id on the network : 014d0ef5.11.75.1.0
  value / items: No Operation Possible / set(['Protection by Sequence', 'Unprotected', 'No Operation Possible'])
node/name/index/instance : 4//0/2
  label/help : Protection/
  id on the network : 014d0ef5.4.75.2.0
  value / items: Unprotected / set(['Protection by Sequence', 'Unprotected', 'No Operation Possible'])
node/name/index/instance : 4//0/6
  label/help : Protection/
  id on the network : 014d0ef5.4.75.6.0
  value / items: Unprotected / set(['Protection by Sequence', 'Unprotected', 'No Operation Possible'])
node/name/index/instance : 4//0/5
  label/help : Protection/
  id on the network : 014d0ef5.4.75.5.0
  value / items: Unprotected / set(['Protection by Sequence', 'Unprotected', 'No Operation Possible'])
node/name/index/instance : 4//0/1
  label/help : Protection/
  id on the network : 014d0ef5.4.75.1.0
  value / items: Unprotected / set(['Protection by Sequence', 'Unprotected', 'No Operation Possible'])
node/name/index/instance : 4//0/3
  label/help : Protection/
  id on the network : 014d0ef5.4.75.3.0
  value / items: Unprotected / set(['Protection by Sequence', 'Unprotected', 'No Operation Possible'])
node/name/index/instance : 4//0/4
  label/help : Protection/
  id on the network : 014d0ef5.4.75.4.0
  value / items: Unprotected / set(['Protection by Sequence', 'Unprotected', 'No Operation Possible'])
------------------------------------------------------------
------------------------------------------------------------
Retrieve battery compatibles devices on the network
------------------------------------------------------------
------------------------------------------------------------
------------------------------------------------------------
Retrieve power level compatibles devices on the network
------------------------------------------------------------
------------------------------------------------------------

------------------------------------------------------------
Driver statistics : {'retries': 0, 'readCnt': 182, 'readAborts': 0, 'routedbusy': 0, 'ACKCnt': 73, 'OOFCnt': 0, 'noack': 0, 'broadcastWriteCnt': 9, 'callbacks': 0, 'writeCnt': 73, 'badChecksum': 0, 'nondelivery': 0, 'CANCnt': 0, 'NAKCnt': 0, 'netbusy': 0, 'SOFCnt': 182, 'broadcastReadCnt': 0, 'badroutes': 0, 'ACKWaiting': 0, 'dropped': 0}
Driver label : Number of messages retransmitted
------------------------------------------------------------

------------------------------------------------------------
Stop network
------------------------------------------------------------
2015-05-26 01:14:06.027 Info, mgr,     Manager::WriteConfig completed for driver with home ID of 0x014d0ef5
INFO:openzwave:ZWave configuration wrote to user directory.
INFO:openzwave:Stop Openzave network.
2015-05-26 01:14:07.028 Info, mgr,     Driver for controller /dev/ttyUSB0 pending removal
2015-05-26 01:14:07.028 Always, ***************************************************************************
2015-05-26 01:14:07.028 Detail, WriteMsg Wait Timeout m_currentMsg=00000000
2015-05-26 01:14:07.028 Always, *********************  Cumulative Network Statistics  *********************
2015-05-26 01:14:07.028 Always, *** General
2015-05-26 01:14:07.029 Always, Driver run time: . .  . 0 days, 0 hours, 0 minutes
2015-05-26 01:14:07.029 Always, Frames processed: . . . . . . . . . . . . . . . . . . . . 182
2015-05-26 01:14:07.029 Always, Total messages successfully received: . . . . . . . . . . 182
2015-05-26 01:14:07.029 Always, Total Messages successfully sent: . . . . . . . . . . . . 73
2015-05-26 01:14:07.029 Always, ACKs received from controller:  . . . . . . . . . . . . . 73
2015-05-26 01:14:07.029 Always, *** Errors
2015-05-26 01:14:07.029 Always, Unsolicited messages received while waiting for ACK:  . . 0
2015-05-26 01:14:07.029 Always, Reads aborted due to timeouts:  . . . . . . . . . . . . . 0
2015-05-26 01:14:07.029 Always, Bad checksum errors:  . . . . . . . . . . . . . . . . . . 0
2015-05-26 01:14:07.029 Always, CANs received from controller:  . . . . . . . . . . . . . 0
2015-05-26 01:14:07.029 Always, NAKs received from controller:  . . . . . . . . . . . . . 0
2015-05-26 01:14:07.029 Always, Out of frame data flow errors:  . . . . . . . . . . . . . 0
2015-05-26 01:14:07.029 Always, Messages retransmitted: . . . . . . . . . . . . . . . . . 0
2015-05-26 01:14:07.029 Always, Messages dropped and not delivered: . . . . . . . . . . . 0
2015-05-26 01:14:07.029 Always, ***************************************************************************
2015-05-26 01:14:09.072 Info, mgr,     Driver for controller /dev/ttyUSB0 removed
2015-05-26 01:14:10.073 Error, mgr,     Manager::GetDriver failed - Home ID 0x014d0ef5 is unknown
2015-05-26 01:14:10.073 Warning, Exception: Manager.cpp:362 - 100 - Invalid HomeId passed to GetDriver
2015-05-26 01:14:10.073 Info, mgr,     GetSendQueueCount() failed - _homeId 21827317 not found
Memory use : 15.078125 Mo

"""

__license__ = """
    This file is part of Janitoo.

    Janitoo is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Janitoo is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Janitoo. If not, see <http://www.gnu.org/licenses/>.

"""
__author__ = 'Sébastien GALLET aka bibi21000'
__email__ = 'bibi21000@gmail.com'
__copyright__ = "Copyright © 2013-2014-2015 Sébastien GALLET aka bibi21000"

from janitoo.mqtt import MQTTClient
from threading import Timer

class DHCPClient(object):
    """The Dynamic Home Configuration Protocol client
    """

    def __init__(self, options):
        """
        """
        self.___options = options
        self.dhcpc_options = None
        self._dhcpc_client = MQTTClient(options=self.__options)
        self._dhcpc_hadd_timer = None
        self._dhcpc_heartbeat_timer = None
        self._dhcpc_heartbeat_timeout = None
        self._dhcpc_callback = None
        self._dhcpc_add_ctrl = -1
        self._dhcpc_add_nodes = {}
        """The nodes managed by the controller including itself
        '0' : {'callback_heartbeat' : a_callback_called_to_check_the_state_of_machine}.

        """
        self.hadd = None
        self._dhcp_tries = 3
        self._dhcp_try_current = 0
        self._dhcp_timeout = 10
        self._dhcp_heartbeat = 60

    def _dhcpc_hadd(self):
        """Check that we receive an HADD before a timeout
        """
        self._dhcpc_hadd_timer = None
        self._dhcpc_hadd_timer = threading.Timer(self._dhcpc_heartbeat_timeout, self._dhcpc_heartbeat)
        self._dhcpc_hadd_timer.start()

    def _dhcpc_heartbeat(self):
        """Manage the heartbeat
        """
        self._dhcpc_heartbeat_timer = None
        self._dhcpc_heartbeat_timer = threading.Timer(self._dhcpc_heartbeat_timeout, self._dhcpc_heartbeat)
        self._dhcpc_heartbeat_timer.start()
        for node in self._dhcpc_add_nodes.keys():
            if self._dhcpc_add_nodes[node]['callback_heartbeat'] == None or self._dhcpc_add_nodes[node]['callback_heartbeat'](node) == True:
                self.mqttc.publish_heartbeat(add_ctrl, add_node)

    def _dhcpc_on_message(self, client, userdata, message):
        """On DHCP message
        """
        pass

    def lock_dhcpc(self, add_node, callback):
        """Get an HADD fron the DHCP server and launch callback at the end of the process
        """
        self._dhcpc_callback = None
        if 'dhcp_tries' in self.__options:
            try:
                self._dhcp_tries = int(self.__options['dhcp_tries'])
            except ValueError:
                pass
        if 'dhcp_timeout' in self.__options:
            try:
                self._dhcp_timeout = int(self.__options['dhcp_timeout'])
            except ValueError:
                pass
        if 'dhcp_heartbeat' in self.__options:
            try:
                self._dhcp_heartbeat = int(self.__options['dhcp_heartbeat'])
            except ValueError:
                pass
        self.dhcpc_options = self.get_options('dhcp')
        add_ctrl = -1
        add_node = -1
        try:
            if "add_ctrl" in options and "add_node" in self.dhcpc_options:
                add_ctrl = int(self.dhcpc_options['add_ctrl'])
                add_node = int(self.dhcpc_options['add_node'])
        except ValueError:
            pass

    def new_dhcpc(self, add_node, callback):
        """Get a new HADD fron the DHCP server and launch callback at the end of the process
        """
        self._dhcpc_callback = None
        if 'dhcp_tries' in self.__options:
            try:
                self._dhcp_tries = int(self.__options['dhcp_tries'])
            except ValueError:
                pass
        if 'dhcp_timeout' in self.__options:
            try:
                self._dhcp_timeout = int(self.__options['dhcp_timeout'])
            except ValueError:
                pass
        if 'dhcp_heartbeat' in self.__options:
            try:
                self._dhcp_heartbeat = int(self.__options['dhcp_heartbeat'])
            except ValueError:
                pass
        self.dhcpc_options = self.get_options('dhcp')
        add_ctrl = -1
        add_node = -1
        try:
            if "add_ctrl" in options and "add_node" in self.dhcpc_options:
                add_ctrl = int(self.dhcpc_options['add_ctrl'])
                add_node = int(self.dhcpc_options['add_node'])
        except ValueError:
            pass

    def release_dhcpc(self, add_node):
        """Release the HADD
        """
        pass
